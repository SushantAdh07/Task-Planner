module.exports = require('./register')().Promise
