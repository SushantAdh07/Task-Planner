export { _ as default } from "../esm/_type_of.js";
