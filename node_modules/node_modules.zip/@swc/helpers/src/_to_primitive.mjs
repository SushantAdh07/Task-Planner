export { _ as default } from "../esm/_to_primitive.js";
