export { _ as default } from "../esm/_apply_decorated_descriptor.js";
