export { _ as default } from "../esm/_call_super.js";
