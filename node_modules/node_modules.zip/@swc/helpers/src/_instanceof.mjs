export { _ as default } from "../esm/_instanceof.js";
