export { _ as default } from "../esm/_is_native_reflect_construct.js";
