export { _ as default } from "../esm/_initializer_warning_helper.js";
