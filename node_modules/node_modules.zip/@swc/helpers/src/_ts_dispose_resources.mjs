export { _ as default } from "../esm/_ts_dispose_resources.js";
